sqlite3 commands for loading file:
example:
.import load/tblHR_Associates.txt

To execute SQL in a file use .read command.