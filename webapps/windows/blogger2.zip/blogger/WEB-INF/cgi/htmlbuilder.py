# Build the beginning part of the HTML page
def beginHTMLnoupload(title):
    print "Content-Type: text/html\n\n"
    print """
<HTML>
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<head><title>%s</title></head>
<body bgcolor="lightblue">
<a href="../index.html">Back to Feed</a><br>
<h4>Profile info:</h4>""" % title

def beginHTMLupload(title):
    print "Content-Type: text/html\n\n"
    print """
<HTML>
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<head><title>%s</title></head>
<script language="javascript" type="text/javascript">
<!--
function validate()
{
   if ((document.form.upfile.value=='')) {
      alert('Please choose a file to upload.');
      document.form.upfile.focus();
      return false;
   }
}
//-->
</script>
<body bgcolor="lightblue">
<a href="../index.html">Back to Feed</a><br>
<h4>Profile info:</h4>""" % title

# Build HTML table  (2 parts to this function: 1st part prints the column names, 2nd part prints the actual resultset
def createHtmlTableUpload(column_name_list, resultset):
    num_columns = len(column_name_list)
    print "<table border=\"4\">"
    print "<tr>"
    for column_name in column_name_list:
        print "<th align=\"center\">" + column_name + "</th>"
    print "</tr>"
    print "<tr>"
    for row in resultset:
        for i in range(num_columns):
            print "<td align=\"center\">" + str(row[i]) + "</td>"
            i = i + 1
        print "</tr>"
    print "</table><br>"
    print "<b>Profile image:<b><br>"
    print '<img src="../' + row[7] + '" height="60" width="60" alt="profile image"/><br><br>'

    print """<h5>Upload your profile image here.  Your profile image will be shown with dimensions 60 pixels wide by 60 pixels high.</h5>
<form name="form" action="/blogger/cgi-bin/fileupload.py" METHOD="POST" ENCTYPE="multipart/form-data" onSubmit='return validate();'>
    <b>Image File: </b> <input type=file name="upfile"><br><br>
    <b>Click </b><input type="submit" value="here"> to upload the file.
</form>"""

def createHtmlTableNoUpload(column_name_list, resultset):
    num_columns = len(column_name_list)
    print "<table border=\"4\">"
    print "<tr>"
    for column_name in column_name_list:
        print "<th align=\"center\">" + column_name + "</th>"
    print "</tr>"
    print "<tr>"
    for row in resultset:
        for i in range(num_columns):
            print "<td align=\"center\">" + str(row[i]) + "</td>"
            i = i + 1
        print "</tr>"
    print "</table><br>"
    print "<b>Profile image:<b><br>"
    print '<img src="../' + row[7] + '" width="60" height="60" alt="profile image"/><br><br>'

# Build/finish the HTML page
def endHTML():
    print """
</body>
</HTML>"""
