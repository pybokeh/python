#!/usr/bin/python
# Python script that allows user to update their profile information.

import os, sys, Cookie
import cgi
import cgitb
import sqlite3
cgitb.enable()


# Check to ensure the user has logged in
a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
try:
    user = a_cookie["user"].value
except:
    http_referer = os.environ['HTTP_REFERER']
    login = http_referer.replace('updateprofile.html','login.html')
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>You must first log in to update your profile.</h2>'
    print '<meta http-equiv="REFRESH" content="2;url=' + login + '">'
    print '</body></html>'


form = cgi.FieldStorage()
notify   = form.getlist("email_notify")  # email_notify is a radio button, a getlist method was needed.  Reference the value using notify[0]
try:
    workext = form["workext"].value
except:
    workext = ''
try:
    beeper = form["beeper"].value
except:
    beeper = ''
try:
    aboutme = form["aboutme"].value
except:
    aboutme = ''

conn = sqlite3.connect("d:\\tomcat\\webapps\\blogger\\WEB-INF\\db\\mydater")
c = conn.cursor()

sql = 'update users set workext = ?, beeper = ?, aboutme = ? , email_notify = ? where userid = ?'

c.execute(sql, [workext, beeper, aboutme, notify[0], user])
conn.commit()
c.close()
conn.close()

http_referer = os.environ['HTTP_REFERER']
home = http_referer.replace('updateprofile.html','index.html')
print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>Your profile was successfully updated.</h2>'
print '<meta http-equiv="REFRESH" content="2;url=' + home + '">'
print '</body></html>'
