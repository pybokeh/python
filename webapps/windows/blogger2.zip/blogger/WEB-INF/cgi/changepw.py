#!/usr/bin/python

import os, cgi, cgitb
import sqlite3
import Cookie
import base64
cgitb.enable()


def verifiedUser(userid, pw):
    conn = sqlite3.connect("d:\\tomcat\\webapps\\blogger\\WEB-INF\\db\\mydater")
    c = conn.cursor()

    sql = """
select
userid

from users

where
userid = ?
and password = ?"""

    c.execute(sql, [userid, pw])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True


form = cgi.FieldStorage()

pw_current   = base64.b64encode( form["password"].value )
pw_new1      = base64.b64encode( form["password1"].value )


# Get userid from the Cookie monster, else I guess they didn't log in
a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
try:
    userid = a_cookie["user"].value
except:
    http_referer = os.environ['HTTP_REFERER']
    login = http_referer.replace('changepw.html','login.html')
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>You must first log in to change your password.</h2>'
    print '<meta http-equiv="REFRESH" content="2;url=' + login + '">'
    print '</body></html>'

if verifiedUser(userid, pw_current):
    conn = sqlite3.connect("d:\\tomcat\\webapps\\blogger\\WEB-INF\\db\\mydater")
    c    = conn.cursor()
    sql  = 'update users set password = ? where userid = ?'
    c.execute(sql, [pw_new1, userid])
    conn.commit()
    c.close()
    conn.close()
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>Your password was successfully changed.</h2>'
    print '<meta http-equiv="REFRESH" content="2;url=../index.html">'
    print '</body></html>'
else:
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>Sorry, your current password was not correct. Hit the back button and re-enter.</h2>\n'
    print '</body></html>'
