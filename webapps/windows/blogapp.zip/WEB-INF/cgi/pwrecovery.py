#!/usr/bin/python
# http://www.python-blog.com/tag/multiple-recipients/

import os, sys, Cookie
import cgi
import cgitb
import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.utils import COMMASPACE
from urlparse import urlparse
cgitb.enable()


def sendPassword(email):
    conn = sqlite3.connect("d:\\tomcat\\webapps\\aq\\WEB-INF\\db\\mydater")
    c = conn.cursor()

    sql = "select password from users where email = ?"

    c.execute(sql, [email])
    conn.commit()

    for row in c:
        pw = row[0]

    c.close()
    conn.close()

    pw_file = open(r'D:\tomcat\webapps\DensoOBD\files\pw\hello.txt', 'r')
    pwd = pw_file.read()
    sender  = 'pyfeeds@gmail.com'
    subject = 'Your AQ feed pw'
    recipient = email
    message = "Your pw is: " + pw + "  You can click here: http://10.44.16.86/aq/login.html  to log in."

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['BCC'] = recipient
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()

    try:
        server.login(sender,pwd)
    except smtplib.SMTPAuthenticationError:               # Check for authentication error
        print "Content-Type: text/html\n\n"
        print """<html>
<h3>Error in authenticating with the email server.</h3>
</html>"""

    try:
        server.sendmail(sender,recipient,msg.as_string())
    except smtplib.SMTPRecipientsRefused:                # Check if recipient's email was accepted by the server
        print "Content-Type: text/html\n\n"
        print """<html>
<h3>Error in sending email notification(s) or your email was not valid.  Check your email address again.</h3>
</html>"""
    server.quit()
    

form = cgi.FieldStorage()
email = form["email"].value

sendPassword(email)

print 'Content-type: text/html\n\n'
print '<html><br>'
print '<meta http-equiv="REFRESH" content="3;url=../login.html">\n'
print '<body bgcolor="lightblue"><p>Your password has been emailed to ' + email + '</p><br>'
print '</body></html>'
