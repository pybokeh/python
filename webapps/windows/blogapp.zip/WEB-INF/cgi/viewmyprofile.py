#!/usr/bin/python

import cgi
import cgitb
import sqlite3
import os, Cookie, htmlbuilder
cgitb.enable()

form = cgi.FieldStorage()
userid = form["userid"].value

conn = sqlite3.connect("d:\\tomcat\\webapps\\aq\\WEB-INF\\db\\mydater")
c = conn.cursor()

sql = """
select
assocnum as "Assoc #",
userid as "User ID",
fname as "First Name",
lname as "Last Name",
workext as "WorkExt",
beeper as "Beeper",
aboutme as "AboutMe",
img_url as "Img URL",
email as "Email",
email_notify as "Email Notify"

from users

where 
userid = ?"""

c.execute(sql, [userid])
conn.commit()

# Get column name of the resultset
column_name_list = [tuple[0] for tuple in c.description]

a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
# if the user is a logged in/registered user, they can view their profile
try:
    user = a_cookie["user"].value
    htmlbuilder.beginHTMLupload("My Profile Info")
    htmlbuilder.createHtmlTableUpload(column_name_list,c)
    htmlbuilder.endHTML()
except:
    htmlbuilder.beginHTML("User Profile Info")
    htmlbuilder.createHtmlTableNoUpload(column_name_list,c)
    htmlbuilder.endHTML()

c.close()
conn.close()
