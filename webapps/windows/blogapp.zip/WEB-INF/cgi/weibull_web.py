# Taken from: http://www.mail-archive.com/matplotlib-users@lists.sourceforge.net/msg05432.html

from numpy import *
from matplotlib.ticker import FuncFormatter
import pylab as p
from urlparse import urlparse
import urllib2, os, cgi, cgitb, sys
# I'm used to  the ln notation for the natural log
from numpy import log as ln
cgitb.enable()

def create_img_save_loc(file_name, url_suffix):
    temp_loc = "d:\\tomcat\\webapps"+url_suffix.replace("/","\\")
    slash_idx = temp_loc.rfind('\\')
    img_save_location = temp_loc[:slash_idx+1] + 'images\\'
    img_file_name = file_name
    return img_save_location + img_file_name

form = cgi.FieldStorage()
beta = float(form["beta"].value)
eta = float(form["eta"].value)

# Paramters
# beta = 1.0
# eta = 8064

# Genrate 10 numbers following a Weibull distribution
x = eta *random.weibull(beta, size=10)
F = 1 - exp( -(x/eta)**beta )

# Estimate Weibull parameters
lnX = ln(x)
lnF = ln( -ln(1-F) )
a, b = polyfit(lnF, lnX, 1)
beta0 = 1/a
eta0  = exp(b)

# ideal line
F0 = array([1e-3, 1-1e-3])
x0 = eta0 * (-ln(1-F0))**(1/beta0)
lnF0 = ln(-ln(1-F0))


# Weibull plot
p.figure()
ax = p.subplot(111)
p.semilogx(x, lnF, "bs")
p.plot(x0, lnF0, 'r-', label="beta= %5G\neta = %.5G" % (beta0, eta0) )
p.grid()
p.xlabel('x')
p.ylabel('Cumulative Distribution Function')
p.legend(loc='lower right')

# ticks
def weibull_CDF(y, pos):
    return "%G %%" % (100*(1-exp(-exp(y))))

formatter = FuncFormatter(weibull_CDF)
ax.yaxis.set_major_formatter(formatter)

yt_F = array([ 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5,
           0.6, 0.7, 0.8, 0.9, 0.95, 0.99])
yt_lnF = ln( -ln(1-yt_F))
p.yticks(yt_lnF)

# Get the request URL so that we can use it to save the chart image in the correct location...
http_referer = os.environ['HTTP_REFERER']
url_parser = urlparse(http_referer)
url_suffix = url_parser.path
fileloc = create_img_save_loc('weibull.png', url_suffix)
p.savefig(fileloc)
# p.show()

# Send user to original page, then refresh the page with new chart
print 'Content-type: text/html\n\n' + '<meta http-equiv="REFRESH" content="0;url=' + http_referer + '">'
