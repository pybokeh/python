#!/usr/bin/python

import cgi, cgitb, os, sys, Cookie
import sqlite3
from datetime import datetime
cgitb.enable()


form = cgi.FieldStorage()
txtSearch = form["txtsearch"].value

searchstring = '%' + txtSearch + '%'


begHTML = open('/home/daniel/apache/webapps/feeds/templates/begHTML.txt','r')
begHTML_lines = begHTML.read()
begHTML.close()


endHTML = open('/home/daniel/apache/webapps/feeds/templates/endHTML.txt','r')
endHTML_lines = endHTML.read()
endHTML.close()

conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
c = conn.cursor()

sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
assocnum,
substr(fname,1,1),
lname,
img_url

from feed f inner join users u on
f.userid = u.userid

where
feedtxt like ?
or u.userid like ?
or assocnum like ?
or lname like ?
or f.datetime_stamp like ?

order by
f.datetime_stamp desc
"""

c.execute(sql, [searchstring, searchstring, searchstring, searchstring, searchstring])
conn.commit()

comment_txt = ''
for row in c.fetchmany(50):  # Limit it so that it shows at most 50 most recent blogs
    userid     = row[0]
    comment    = row[1]
    datesample = row[2]
    assocnum   = row[3]
    finit      = row[4]
    lname      = row[5]
    myImg      = row[6]

    year  = int(datesample[:4])
    month = int(datesample[5:7])
    day   = int(datesample[8:10])
    hour  = int(datesample[11:13])
    mins  = int(datesample[14:16])
    sec   = int(datesample[17:19])
    mydate = datetime(year, month, day, hour, mins, sec)

    user = finit + ' ' + lname + '-' + assocnum

    comment_txt = comment_txt + '<TR>' + '\n' \
    + '    <TD rowspan="2" align="center"><a href="viewprofile.py?userid=' + userid + '">' \
    + '<img src="../' + myImg + '"></a>' + '\n' \
    + '    </TD>' + '\n' \
    + '    <TD><FONT face="Verdana,Helvetica" COLOR="#00008B" SIZE="2"><b>' + user + ':</b>&nbsp;</FONT><FONT face="Verdana,Helvetica" SIZE="3">' + comment + '</FONT>' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n' \
    + '<TR>' + '\n' \
    + '    <TD><FONT face="Verdana,Helvetica" SIZE="1">'+ mydate.strftime("%m/%d/%Y - %I:%M%p") + '</FONT>' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n' \
    + '<TR>' + '\n' \
    + '    <TD>&nbsp;' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n'


c.close()
conn.close()

completeHTML = begHTML_lines + comment_txt + endHTML_lines

print 'Content-type: text/html\n\n'
print completeHTML
