#!/usr/bin/python

import os, cgi, cgitb, sys
import sqlite3
import Cookie
cgitb.enable()

def set_client_cookie(user):
    a_cookie = Cookie.SimpleCookie()
    a_cookie["user"] = user
    print "Content-Type: text/html"
    print a_cookie, "\n\n"

form = cgi.FieldStorage()

user = form["user"].value
pw   = form["password"].value

# conn = sqlite3.connect("/home/daniel/apache/webapps/aq/db/mydater")     on LINUX
conn = sqlite3.connect("d:\\tomcat\\webapps\\aq\\WEB-INF\\db\\mydater")
c    = conn.cursor()

sql = """
select
userid,
password

from users

where
userid = ?
and password = ?"""

c.execute(sql, [user,pw])
conn.commit()

if c.fetchone() == None:
    http_referer = os.environ['HTTP_REFERER']
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h2>Invalid user id and/or password.</h2>\n'
    print '<meta http-equiv="REFRESH" content="2;url=' + http_referer + '">\n'
    print '</body></html>'
    c.close()
    conn.close()
    sys.exit()
else:
    set_client_cookie(user)
    http_referer = os.environ['HTTP_REFERER']
    blog_url = http_referer.replace('login.html','cgi-bin/feedgenerator.py')
    print '<meta http-equiv="REFRESH" content="0;url=' + blog_url + '">'
        
