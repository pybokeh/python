#!/usr/bin/python
# Simple blogger application that uses sqlite3 to store feed and user info.
# To convert between windows to linux, must take note of root server directory,
#     windows' back slash, and the "\r\n" carriage return.

import os, sys, Cookie
import cgi
import cgitb
import sqlite3
from datetime import datetime
from urlparse import urlparse
cgitb.enable()

def hyperlinker (full_text, target, hyperlink):
    if target == None or hyperlink == None:
        return full_text
    else:
        if full_text.find(target) == -1:
            print 'Content-type: text/html\n\n' + '<h2>Your target word was not found.  Hit the back button.</h2>'
            sys.exit()
        else:
            anchor = '<a href="' + hyperlink + '">' + target + "</a>"
            return full_text.replace(target, anchor)

def insertFeed(userid, txt, datetime_stamp):
    conn = sqlite3.connect("d:\\tomcat\\webapps\\feeds\\WEB-INF\\db\\mydater")
    c = conn.cursor()

    sql = """
    insert into feed (userid, feedtxt, datetime_stamp)
    values (?, ?, ?)"""

    c.execute(sql, [userid, txt, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()    

def getProfile(userid):
    conn = sqlite3.connect("d:\\tomcat\\webapps\\feeds\\WEB-INF\\db\\mydater")
    c = conn.cursor()

    sql = """
    select
    assocnum,
    substr(fname,1,1),
    lname,
    img_url

    from users

    where
    userid = ?"""

    c.execute(sql, [userid])
    conn.commit()

    for row in c:
        assocnum = row[0]
        finit    = row[1]
        lname    = row[2]
        img_url  = row[3]

    user = finit + ' ' + lname + '-' + assocnum
    
    c.close()
    conn.close()

    return user, img_url


def generateFeed(userid, comment):
   user, myImg = getProfile(userid)
   comment_txt = '<TR>' + '\n' \
    + '    <TD rowspan="2" align="center"><a href="cgi-bin/viewprofile.py?userid=' + userid + '">' \
    + '<img src="' + myImg + '"></a>' + '\n' \
    + '    </TD>' + '\n' \
    + '    <TD><FONT face="Verdana,Helvetica" COLOR="#00008B" SIZE="2"><b>' + user + ':</b>&nbsp;</FONT><FONT face="Verdana,Helvetica" SIZE="3">' + comment + '</FONT>' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n' \
    + '<TR>' + '\n' \
    + '    <TD><FONT face="Verdana,Helvetica" SIZE="1">'+ mydate.strftime("%m/%d/%Y - %I:%M%p") + '</FONT>' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n' \
    + '<TR>' + '\n' \
    + '    <TD>&nbsp;' + '\n' \
    + '    </TD>' + '\n' \
    + '</TR>' + '\n'
   return comment_txt

def getClientCookie():
    a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
    try:
        user = a_cookie["user"].value
    except:
        print 'Content-type: text/html\n\n' + '<h2>You do not have permission to add to this feed.  You must first log in <a href="../login.html">here</a>.</h2>'
        sys.exit()
    return user
    

form = cgi.FieldStorage()
comment = form["comment"].value

userid = getClientCookie()

try:
    target = form["target"].value
    hlink  = form["hlink"].value
except:
    target = None
    hlink  = None


# Get the date/time the user added blog and then format it as 'mm/dd/YYYY - hh:mmAM/PM'
mydate = datetime_stamp = datetime.now()

# Go get the URL/html page that the user requested
http_referer = os.environ['HTTP_REFERER']  # For example:  http://localhost/feeds/blogger.html

# Now just get the URL suffix, we don't care about the full URL
url_parser = urlparse(http_referer)
url_suffix = url_parser.path   # url_suffix = "/feeds/blogger.html"

# Now concatenate the URL suffix with physical drive location of the webapp directory
orig_file = "d:\\tomcat\\webapps"+url_suffix.replace("/","\\")    # replace forward slash with back slash since we're on windows
# original file = "d:\tomcat\webapps\feeds\blogger.html"

# Now prepare temporary file which we will later replace the original file with, we are going to keep the same name, but add _bak at the end
temp_file = orig_file.replace(".html","_bak.html")
# temporary file = "d:\tomcat\webapps\feeds\blogger_bak.html"

# Now create input file for read-only access and output file for write access
input_file = open(orig_file,'r')
output_file = open(temp_file,'w')

# Get the comment that the user entered in the HTML text box, then format it for HTML
comment = comment.replace('<','&#60;').replace('>','&#62;')

comment_finalized = hyperlinker(comment, target, hlink)

insertFeed(userid, comment_finalized, datetime_stamp)

comment_formatted = generateFeed(userid, comment_finalized)

# Read the entire contents of the orginal file as lines stored in a list (a list of lines)
lines_list = input_file.readlines()  #  FYI, this is very inefficient. Do not use readlines() if there are several thousands of comments...

input_file.close()

# Find where the first comment is in the HTML page
index = lines_list.index("<!-- START BLOG -->\n")

# Now insert the new comment at the top of the comments
lines_list.insert(index+1,comment_formatted)

# Now write the contents of the new HTML file to the temporary output file
for line in lines_list:
    output_file.write(line)

output_file.close()

# Now swap the original file with the temporary file with updated user comments
in_file = open(temp_file,'r')
out_file = open(orig_file,'w')

in_file_contents = in_file.read()
out_file.write(in_file_contents)

in_file.close()
out_file.close()

# Now, refresh the page with newly added comment-we're done!
print 'Content-type: text/html\n\n' + '<meta http-equiv="REFRESH" content="0;url=' + http_referer + '">'
