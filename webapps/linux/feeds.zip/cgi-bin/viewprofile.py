#!/usr/bin/python

import cgi
import cgitb
import sqlite3
import htmlbuilder
cgitb.enable()

form = cgi.FieldStorage()
userid = form["userid"].value

conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
c = conn.cursor()

sql = """
select
assocnum as "Assoc #",
userid as "User ID",
fname as "First Name",
lname as "Last Name",
workext as "WorkExt",
beeper as "Beeper",
aboutme as "AboutMe",
img_url as "Img URL"

from users

where 
userid = ?"""

c.execute(sql, [userid])
conn.commit()

# Get column name of the resultset
column_name_list = [tuple[0] for tuple in c.description]

htmlbuilder.beginHTMLnoupload("My Profile Info")
htmlbuilder.createHtmlTableNoUpload(column_name_list,c)
htmlbuilder.endHTML()

c.close()
conn.close()
