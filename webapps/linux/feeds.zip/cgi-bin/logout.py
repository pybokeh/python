#!/usr/bin/python

import os, cgi, cgitb, sys
import sqlite3
import Cookie
cgitb.enable()

try:
    http_referer = os.environ['HTTP_REFERER']
    a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
    a_cookie["user"]["expires"] = "01/01/90 00:00:00 GMT"
    print "Content-Type: text/html"
    print a_cookie, "\n\n"
    login = http_referer.replace("cgi-bin/feedgenerator.py","login.html")
    print '<body bgcolor="lightblue"><h3>You have been succesfully logged out.</h3>\n'
    print '<meta http-equiv="REFRESH" content="2;url=' + login + '">'
    print '</body></html>'
except:
    print 'Content-type: text/html\n\n' + '<body bgcolor="lightblue"><h3>You have already been logged out or you are viewing as a guest.  Click the back button or click <a href="../login.html">here</a> to log back in.</h3>'
    print '</body></html>'
