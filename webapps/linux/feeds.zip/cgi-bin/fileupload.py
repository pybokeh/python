#!/usr/bin/python

import cgi, cgitb, os
import sqlite3, Cookie
from urlparse import urlparse
cgitb.enable()

def updateProfileImage(filename):
    a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
    try:
        user = a_cookie["user"].value
        filenameURL = "images/" + filename
        conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
        c = conn.cursor()

        sql = "update users set img_url = ? where userid = ?"

        c.execute(sql, [filenameURL, user])
        conn.commit()
        c.close()
        conn.close() 
    except:
        login = http_referer.replace("cgi-bin/fileupload.py","login.html")
        print 'Content-type: text/html\n\n' + '<meta http-equiv="REFRESH" content="3;url=' + login + '">'
        print '<body bgcolor="lightblue">'
        print 'You have to first log in to update your profile image.'
        print '</body></html>'

http_referer = os.environ['HTTP_REFERER']  # For example: http://localhost/feeds/cgi-bin/viewmyprofile.py

# Now just get the URL suffix, we don't care about the full URL
url_parser = urlparse(http_referer)
url_suffix = url_parser.path  # /feeds/cgi-bin/viewmyprofile.py
url_suffix = url_suffix.replace("cgi-bin","images")
# url_suffix = '/feeds/images/viewmyprofile.py'

file = "/home/daniel/apache/webapps"+url_suffix
# file = '/home/daniel/apache/webapps/feeds/images/viewmyprofile.py'
index = file.rfind("/")  # Find right-most forward slash (linux)
file_location = file[:index+1]  # file location = /home/daniel/apache/webapps/feeds/images/

try: # Windows needs stdio set for binary mode.
    import msvcrt
    msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
    msvcrt.setmode (1, os.O_BINARY) # stdout = 1
except ImportError:
    pass

form = cgi.FieldStorage()

# Generator to buffer file chunks
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk


fileitem = form["upfile"]

# Test if the file was uploaded
if fileitem.filename:

   # strip leading path from file name to avoid directory traversal attacks
   fn = os.path.basename(fileitem.filename)
   f = open(file_location + fn, 'wb', 10000)

   # Read the file in chunks
   for chunk in fbuffer(fileitem.file):
      f.write(chunk)
   f.close()
   message = 'The file "' + fn + '" was uploaded successfully'

else:
   message = 'No file was uploaded'

updateProfileImage(fn)

index_file = open(file_location+"index.html",'w')
index_file.write('<html><body bgcolor="lightblue">')
index_file.write("<h5>DISCLAIMER: The contents of this web page do not necessarily reflect the views or principles of Honda of America Manufacturing, Inc., Honda Motor Ltd., or any of their affiliates.</h5>")

for filename in os.listdir(file_location):
    if (os.path.isfile(file_location+filename) and filename != "index.html"):
        index_file.write("<A HREF=\""+filename+"\">"+filename+"</A><br>\n")

index_file.write("</body></html>")
index_file.close()

print 'Content-type: text/html\n\n' + '<meta http-equiv="REFRESH" content="0;url=' + http_referer + '">'
print '<body bgcolor="lightblue">'
print '</body></html>'
