#!/usr/bin/python
# Python script used to register users.

import os, sys, Cookie
import cgi
import cgitb
import sqlite3
from datetime import datetime
from urlparse import urlparse
cgitb.enable()

def setClientCookie(user):
    a_cookie = Cookie.SimpleCookie()
    a_cookie["user"] = user
    print "Content-Type: text/html"
    print a_cookie, "\n\n"

def registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, datetime_stamp):
    conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
    c = conn.cursor()

    sql = """
insert into users values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    c.execute(sql, [assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def hasRegistered(userid):
    conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
    c = conn.cursor()

    sql = """
select
userid

from users

where
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True


form = cgi.FieldStorage()
assocno  = form["assocno"].value
userid   = form["userid"].value
fname    = form["fname"].value.upper()
lname    = form["lname"].value.upper()
password = form["password"].value
try:
    workext = form["workext"].value
except:
    workext = ''
try:
    beeper = form["beeper"].value
except:
    beeper = ''
try:
    aboutme = form["aboutme"].value
except:
    aboutme = '' 

http_referer = os.environ['HTTP_REFERER']

if hasRegistered(userid):
    print 'Content-type: text/html\n\n' + '<h2>Sorry, you have already registered.  Contact the admin if you have forgotten your password.  You may click the back button to try again or click <a href="feedgenerator.py">here</a> to proceed to the feed access.</h2>'
    sys.exit()
else:
    datetime_stamp = datetime.now()
    registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, "images/default.bmp", datetime_stamp)

    setClientCookie(userid)

    blog_url = http_referer.replace('register.html','cgi-bin/feedgenerator.py')
    print '<meta http-equiv="REFRESH" content="3;url=' + blog_url + '">\n'
    print '<body bgcolor="lightblue"><H3>Thank you ' + fname + ' ' + lname + ' for registering!  You will be forwarded to the feed in 3 seconds...</H3>\n'
    print '</body></html>'
