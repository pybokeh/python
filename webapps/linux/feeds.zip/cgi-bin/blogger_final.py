#!/usr/bin/python

import os, sys, Cookie
import cgi
import cgitb
import sqlite3
from datetime import datetime
from urlparse import urlparse
cgitb.enable()

def hyperlinker (full_text, target, hyperlink):
    if target == None or hyperlink == None:
        return full_text
    else:
        if full_text.find(target) == -1:
            print 'Content-type: text/html\n\n' + '<h2>Your target word was not found.  Hit the back button.</h2>'
            sys.exit()
        else:
            anchor = '<a href="' + hyperlink + '">' + target + "</a>"
            return full_text.replace(target, anchor)

def insertFeed(userid, txt, datetime_stamp):
    conn = sqlite3.connect("/home/daniel/apache/webapps/feeds/db/mydater")
    c = conn.cursor()

    sql = """
    insert into feed (userid, feedtxt, datetime_stamp)
    values (?, ?, ?)"""

    c.execute(sql, [userid, txt, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()    

def getClientCookie():
    a_cookie = Cookie.SimpleCookie( os.environ.get("HTTP_COOKIE") )
    try:
        user = a_cookie["user"].value
    except:
        print 'Content-type: text/html\n\n' + '<h2>You do not have permission to add to this feed.  You must first log in <a href="../login.html">here</a>.</h2>'
        sys.exit()
    return user
    

form = cgi.FieldStorage()
comment = form["comment"].value

userid = getClientCookie()

try:
    target = form["target"].value
    hlink  = form["hlink"].value
except:
    target = None
    hlink  = None

# Get the date/time the user added blog and then format it as 'mm/dd/YYYY - hh:mmAM/PM'
mydate = datetime_stamp = datetime.now()

# Go get the URL/html page that the user requested
http_referer = os.environ['HTTP_REFERER']  # For example:  http://localhost/feeds/cgi-bin/feedgenerator.py

# Get the comment that the user entered in the HTML text box, then format it for HTML
comment = comment.replace('<','&#60;').replace('>','&#62;')

hypcomment = hyperlinker(comment, target, hlink)
insertFeed(userid, hypcomment, datetime_stamp)

# Now, refresh the page with newly added comment-we're done!
print 'Content-type: text/html\n\n' + '<meta http-equiv="REFRESH" content="0;url=' + http_referer + '">'
