insert or replace into lwc_angles_no_dupes (txtVIN, Pitch_OFFSET, Roll_OFFSET, Yaw_OFFSET, datTime, txtMY, txtModel, txtPlant, testYrMonth)

select
txtVIN,
pitch_offset,
roll_offset,
yaw_offset,
date(max(datTime)),
txtMY,
txtModel,
txtPlant,
strftime('%Y-%m',date(max(datTime)))

from lane_watch

group by
txtVIN

