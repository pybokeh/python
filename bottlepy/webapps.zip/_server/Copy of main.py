from bottle import debug, run
# import webapps
import www, denso, engine, captions, aq, survey, logging
debug(True)  # Turn on debugging for more helpful error messages

# For production applications, run cherrypy
run(host='10.44.16.76', port=80, server='cherrypy')

# For development or quick prototyping, using Bottle's built-in wsgi server
# run(host='10.44.16.76', port=80)

