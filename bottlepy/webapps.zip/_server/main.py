# Reference for wsgilog: https://gist.github.com/3654741

import bottle
from bottle import request, response, redirect
from wsgilog import WsgiLog
# import custom webapps
import www, denso, engine, captions, aq, survey, logging, tpms

app = bottle.app()

# This hook allows you to execute code before or after all URL requests
"""@app.hook('before_request')
def before_request():
    request.environ['wsgilog.logger'].info('Before request to %s %s %s %s' % (request.remote_addr, request.method, request.path, response.status_code))
    if request.remote_addr[:7] == '207.131' or request.remote_addr[:7] == '207.130':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/HAM/default.aspx')


app = WsgiLog(app, tostream=True)"""

bottle.debug(True)
#bottle.run(app=app, host='10.44.16.76', port=80, server='cherrypy')

# Run this if you want to run bottle with built-in reference WSGI server
bottle.run(app=app, host='10.44.16.76', port=80)
