from datetime import date
from datetime import timedelta

#############################  TRW Lot Code Logic  #############################
# strLotCode = '3431T'
def trw_lot2date(strLotCode):
    days_since = int(strLotCode[:3])
    year_num = int(strLotCode[3:4])
    year = 2010 + year_num
    initial_date = date(year,1,1)
    lot_date = initial_date + timedelta(days=days_since - 1)
    return lot_date


#############################  Pacific Lot Code Logic  #########################
# strLotCode = '07C11'
def pacific_lot2date(strLotCode):
    pacific_month_dictionary = {'1':1, '2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'A':10, 'B':11, 'C':12}
    year_num = strLotCode[:2] # 07
    year = int('20'+year_num)  # 2007
    day_of_month = int(strLotCode[-2:])
    pacific_month = strLotCode[2:3]
    month = pacific_month_dictionary[pacific_month]
    lot_date = date(year,month,day_of_month)
    return lot_date


#############################  Continental Lot Code Logic  #########################
# strLotCode = '11175'
def continental_lot2date(strLotCode):
    days_since = int(strLotCode[-3:])
    year_num = strLotCode[:2]
    year = int('20'+year_num)
    initial_date = date(year,1,1)
    lot_date = initial_date + timedelta(days=days_since - 1)
    return lot_date
