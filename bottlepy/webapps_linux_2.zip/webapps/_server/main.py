from bottle import debug, request, response, redirect, run, app
# import webapps
import www
from wsgilog import WsgiLog

debug(True)  # Turn on debugging for more helpful error messages

app = app()

# This hook allows you to execute code before or after all URL requests
@app.hook('before_request')
def before_request():
    request.environ['wsgilog.logger'].info('--- %s %s %s %s' % (request.remote_addr, request.method, request.path, response.status_code))
    if request.remote_addr[:7] == '207.131' or request.remote_addr[:7] == '207.130':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://www.xvideos.com')

app = WsgiLog(app, tostream=True)

run(app=app, host='192.168.2.20', port=8080, reloader=True, server='cherrypy')

# run(host='192.168.2.20', port=8080, reloader=True)
