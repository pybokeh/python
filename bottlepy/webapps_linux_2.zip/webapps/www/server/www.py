from bottle import route, static_file, request, response, template
from urlparse import urlparse
import os

#####################  Routings for www webapp  #####################
@route('/www/<filename>')
def server_static(filename):
    return static_file(filename, root='/home/pybokeh/webapps/www')

@route('/www/files/<filename>')
def static_files(filename):
    return static_file(filename, root='/home/pybokeh/webapps/files')

@route('/www/source/<filename>')
def static_source(filename):
    response.set_header('Content-Type','text/plain')
    return static_file(filename, root='/home/pybokeh/webapps/www/source')

@route('/www/images/<filename>')
def static_images(filename):
    return static_file(filename, root='/home/pybokeh/webapps/www/images')

@route('/www/vids/<filename>')
def static_vids(filename):
    return static_file(filename, root='/home/pybokeh/webapps/www/vids')


###############################################  Routes for Viewable Directories  ###############################################
@route('/www/images/index')
def showImages():
    return showListingsWithoutFileUpload()

@route('/www/files/index')
def showFiles():
    return showListingsWithoutFileUpload()

####################################################  Dynamic Routings  ########################################################
@route('/www/upload', method='POST')
def upload():
    # Get the URL that the FileUpload.html is located at (ex: http://localhost/www/images/FileUpload.html)
    requestURL = request.environ.get('HTTP_REFERER')
    url_parser = urlparse(requestURL)

    # Get just the URL suffix (ex: /www/images/FileUpload.html)
    url_suffix = url_parser.path
    
    # Now map the URL suffix to the server webapp directory
    request_path = "/home/pybokeh/webapps"+url_suffix

    # But we don't need the "FileUpload.html" in the path, so exclude it from the path by finding the right-most backslash
    index = request_path.rfind("/")
    root_path = request_path[:index+1]  # root_path = '/home/pybokeh/webapps/www/images/'

    # Get the file item from the FileUpload.html form
    fileitem = request.POST.get('upfile', '')

    # upload the file to the server at the designated path
    return upload(fileitem, root_path)

######################################################  Helper Functions  #######################################################
def showListings():
    """ This method returns a list of files within the directory that is specified in the URL"""

    url_suffix = request.urlparts[2] # /www/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /www/images/

    server_path = "/home/pybokeh/webapps"+url_path

    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template("/home/pybokeh/webapps/_templates/create_index.tpl", files=filelist)

    return output

def showListingsWithoutFileUpload():
    """ This method returns a list of files (except FileUpload.html) within the directory that is specified in the URL"""

    url_suffix = request.urlparts[2] # /www/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /www/images/

    server_path = "/home/pybokeh/webapps"+url_path

    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            if filename != "FileUpload.html":
                filelist.append(filename)

    output = template("/home/pybokeh/webapps/_templates/create_index.tpl", files=filelist)

    return output

# Generator to buffer file chunks during file upload
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk

# Main file upload function
def upload(filenm, path):

    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = filenm
    root_path = path

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'
