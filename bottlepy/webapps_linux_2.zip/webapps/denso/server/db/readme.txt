To execute SQL in a file:
example:
.read create/user_table.txt