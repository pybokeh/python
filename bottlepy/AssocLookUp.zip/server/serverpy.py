from bottle import debug, route, static_file, request, response, template, run
import pyodbc, base64
# import from user-created module from the PYTHONPATH
import AssocLookUp
debug(True)  # Turn on debugging

@route('/www/<filename>')
def server_static(filename):
    return static_file(filename, root=r'D:\webapps\www')

@route('/www/source/<filename>')
def static_source(filename):
    response.set_header('Content-Type','text/plain')
    return static_file(filename, root=r'D:\webapps\www\source')

@route('/www/images/<filename>')
def static_images(filename):
    return static_file(filename, root=r'D:\webapps\www\images')

@route('/www/vids/<filename>')
def static_vids(filename):
    return static_file(filename, root=r'D:\webapps\www\vids')

@route('/www/AssocInfo', method='POST')
def AssocInfo():
    # Get password and "de-fuzzy" it
    pw_file = open(r'D:\tomcat\webapps\python\WEB-INF\cgi\pw.txt', 'r')
    pw = base64.b64decode(pw_file.read())
    userid = 'ma17151'
    pw_file.close()
    
    querystr = request.POST.get('qryParameter', '').strip()
    cnxn_string = 'DSN=DSNOGW01;UID=' + userid + ';PWD=' + pw

    cnxn = pyodbc.connect(cnxn_string)
    cursor = cnxn.cursor()

    # Get the resultset
    result = AssocLookUp.getResultset(querystr, cursor)

    # Get column name of the resultset
    column_name_list = [tuple[0] for tuple in cursor.description]
    
    cursor.close()

    output = template('make_table', rows=result, column_names=column_name_list)
    return output

    # return '<p>The resultset is %s</p>' % result

run(host='10.44.16.86', port=8080)
