import pyodbc as pyodbc
import sys
import cgi, cgitb
import excelexport
import base64
cgitb.enable()

pw_file = open(r'D:\tomcat\webapps\python\WEB-INF\cgi\pw.txt', 'r')
pw = base64.b64decode(pw_file.read())
userid = 'ma17151'

form = cgi.FieldStorage()
querystr = form.getvalue('sqlString')

cnxn_string = 'DSN=DSNOGW01;UID=' + userid + ';PWD=' + pw

cnxn = pyodbc.connect(cnxn_string)
cursor = cnxn.cursor()

try:
    cursor.execute(querystr)
except:
    print "Content-Type: text/html\n\n"
    print "There is an error in your SQL.  Click the browser's back button."
    sys.exit()

resultset = cursor.fetchall()


# Get column name of the resultset
column_name_list = [tuple[0] for tuple in cursor.description]

# Now create the response HTML page containing the resultset of the query
excelexport.beginHTML("HAM Associate Lookup")
excelexport.createHtmlTable(column_name_list,resultset)
excelexport.endHTML()
    
cursor.close()
