from bottle import route, static_file, request, response, redirect, template
from datetime import datetime
from urlparse import urlparse
import os, sqlite3, base64

####################################################  Static Routings  #######################################################
@route('/denso/<filename>')  # Contains all the html forms
def server_static(filename):
    return static_file(filename, root='/home/pybokeh/webapps/denso/server')

@route('/denso/source/<filename>')  # Contains source files
def static_source(filename):
    return static_file(filename, root='/home/pybokeh/webapps/denso/source')

@route('/denso/images/<filename>')  # Contains image files
def static_images(filename):
    return static_file(filename, root='/home/pybokeh/webapps/denso/images')

@route('/denso/vids/<filename>')   # Contains video files
def static_vids(filename):
    return static_file(filename, root='/home/pybokeh/webapps/denso/vids')


####################################################  Dynamic Routings  #####################################################
@route('/denso/request.urlparts')
def requestURL():
    return "scheme: " + request.urlparts[0] + "<br>" + \
           "host: " + request.urlparts[1] + "<br>" + \
           "path: " + request.urlparts[2] + "<br>" + \
           "query_string: " + request.urlparts[3]

@route('/denso/register', method='POST')
def register():
    assocno = request.POST.get('assocno', '').strip()
    userid  = request.POST.get('userid', '').strip()
    fname   = request.POST.get('fname', '').strip()
    lname   = request.POST.get('lname', '').strip()
    workext = request.POST.get('workext', '').strip()
    beeper  = request.POST.get('beeper', '').strip()
    aboutme = request.POST.get('aboutme', '').strip()
    email   = request.POST.get('email', '').strip()
    email_notify = request.POST.get('email_notify', '').strip()
    password = base64.b64encode( request.POST.get('password', '').strip() )

    if hasRegistered(userid):
        output = template('/home/pybokeh/webapps/denso/templates/alreadyRegistered.tpl')
        return output
    else:
        datetime_stamp = datetime.now()
        registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, "images/default.bmp", email, email_notify, datetime_stamp)
        response.set_cookie('user', userid)
        output = template('/home/pybokeh/webapps/denso/templates/registrationSuccess.tpl', firstname=fname, lastname=lname)
        return output + '<meta http-equiv="REFRESH" content="3;url=/denso/showfeed">'

@route('/denso/login', method='POST')
def login():
    userid = request.POST.get('user', '').strip()
    pw     = base64.b64encode( request.POST.get('password', '').strip() )
    if validUser(userid, pw):
        response.set_cookie('user', userid)
        redirect('/denso/showfeed')
    else:
        output = template('/home/pybokeh/webapps/denso/templates/invalid_user.tpl')
        return output

@route('/denso/postmessage', method='POST')
def postMessage():
    userid  = request.get_cookie('user')
    comment = request.POST.get('comment', '').strip()
    target  = request.POST.get('target', '').strip()
    hlink   = request.POST.get('hlink', '').strip()
    datetime_stamp = datetime.now()
    # Get the comment that the user entered in the HTML text box, then format it for HTML
    comment = comment.replace('<','&#60;').replace('>','&#62;')

    hypcomment = hyperlinker(comment, target, hlink)

    if userid:
        insertPost(userid, hypcomment, datetime_stamp)
        redirect('/denso/showfeed')
    else:
        return "You have to be logged in before you can post your message."

@route('/denso/showfeed')
def showFeed():
    userid = request.get_cookie('user')
    
    if userid:
        resultset = getFeedResultSet()
        output = template('/home/pybokeh/webapps/denso/templates/feed_logged_in.tpl', rows=resultset)
        return output
    else:
        resultset = getFeedResultSet()
        output = template('/home/pybokeh/webapps/denso/templates/feed_logged_out.tpl', rows=resultset)
        return output

@route('/denso/viewprofile', method='GET')
def viewProfile():
    userid = request.GET.get('userid')
    resultset = getUserProfile(userid)
    column_name_list = resultset['column_names']
    row_data_list    = resultset['row_data']
    output = template('/home/pybokeh/webapps/denso/templates/viewprofile.tpl', user=userid, column_names=column_name_list, row_data=row_data_list)
    return output

@route('/denso/logout')
def logOut():
    userid = request.get_cookie('user')
    response.set_cookie('user', userid, expires=-1)
    output = template('/home/pybokeh/webapps/denso/templates/logged_out.tpl')
    return output

@route('/denso/images/upload', method='POST')
def upload():
    url_suffix = request.urlparts[2]
    request_path = "/home/pybokeh/webapps"+url_suffix.replace("/","\\")
    index = request_path.rfind("\\")
    root_path = request_path[:index+1]

    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = request.POST.get('upfile', '')

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'
    

###################################################  Below are helper functions  ##################################################

def registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp):
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
insert into users values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    c.execute(sql, [assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def hasRegistered(userid):
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
select
userid

from users

where
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def validUser(userid, pw):
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
select
userid,
password

from users

where
userid = ?
and password = ?"""

    c.execute(sql, [userid,pw])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def hyperlinker (full_text, target, hyperlink):
    if target == '' or hyperlink == '':
        return full_text
    else:
        if full_text.find(target) == -1:
            print '<h2>Your target word was not found.  Hit the back button.</h2>'
            sys.exit()
        else:
            anchor = '<a href="' + hyperlink + '">' + target + "</a>"
            return full_text.replace(target, anchor)

def insertPost(userid, txt, datetime_stamp):
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
    insert into feed (userid, feedtxt, datetime_stamp)
    values (?, ?, ?)"""

    c.execute(sql, [userid, txt, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def sendEmail():
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = "select email from users where email_notify = 'True'"

    c.execute(sql)
    conn.commit()

    recipient = []
    for row in c:
        recipient.append(row[0])

    c.close()
    conn.close()

    pw_file = open(r'D:\tomcat\webapps\DensoOBD\files\pw\hello.txt', 'r')
    pwd = pw_file.read()
    sender  = 'pyfeeds@gmail.com'
    subject = 'Feed Notification'
    message = "A post has been made to the Denso Feed:  http://10.44.16.86/denso/showfeed  Do NOT reply."

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['BCC'] = COMMASPACE.join(recipient)
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()

    try:
        server.login(sender,pwd)
    except smtplib.SMTPAuthenticationError:               # Check for authentication error
        return "ERROR"

    try:
        server.sendmail(sender,recipient,msg.as_string())
    except smtplib.SMTPRecipientsRefused:                # Check if recipient's email was accepted by the server
        return "ERROR"
    server.quit()

def getFeedResultSet():
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
assocnum,
substr(fname,1,1),
lname,
img_url

from feed f inner join users u on
f.userid = u.userid

order by
f.datetime_stamp desc
"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchmany(50)
    c.close()
    conn.close()

    return resultset

def getUserProfile(user):
    userid = user
    conn = sqlite3.connect('/home/pybokeh/webapps/denso/server/db/denso')
    c = conn.cursor()

    sql = """
select
assocnum as "Assoc #",
userid as "User ID",
fname as "First Name",
lname as "Last Name",
workext as "WorkExt",
beeper as "Beeper",
aboutme as "AboutMe",
img_url as "Img URL",
email as "Email",
email_notify as "Email Notify"

from users

where 
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()
    row_data_list = c.fetchone()
    column_name_list = [tuple[0] for tuple in c.description]
    c.close()
    conn.close()
    resultset = {'column_names':column_name_list, 'row_data':row_data_list}
    return resultset


# Generator to buffer file chunks
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk
