def getResultset(querystr, cursor):
    if len(querystr)==17: # if 17 character, assume user entered a VIN
        cursor.execute("SELECT * FROM tpms_id WHERE txtVIN = ? ORDER BY datTime desc, txtVariable asc", querystr.upper())
    else:
        cursor.execute("SELECT * FROM tpms_id WHERE txtValue = ? ORDER BY datTime desc", querystr.upper())

    resultset = cursor.fetchall()
    return resultset
