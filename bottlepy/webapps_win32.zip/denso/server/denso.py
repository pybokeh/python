from bottle import route, static_file, request, response, redirect, template
from datetime import datetime
from email.mime.text import MIMEText
from email.utils import COMMASPACE
from urlparse import urlparse
import os, sqlite3, base64, smtplib, pyodbc
import TpmsLookUp, VinLookUp, tpms_lot2date, WpiLeftJoinWpt


####################################################  Static Routings  #######################################################
@route('/denso/<filename>')
def server_static(filename):
    return static_file(filename, root=r'D:\webapps\denso')

@route('/denso/source/<filename>')
def static_source(filename):
    return static_file(filename, root=r'D:\webapps\denso\source')

@route('/denso/images/<filepath:path>')
def static_images(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\images')

@route('/denso/vids/<filepath:path>')
def static_vids(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\vids')

@route('/denso/files/<filepath:path>')
def static_files(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\files')

@route('/denso/audio/<filepath:path>')
def static_files(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\audio')

@route('/denso/rss/<filepath:path>')
def static_rss(filepath):
    response.content_type = 'text/xml'
    return static_file(filepath, root=r'D:\webapps\denso\rss')

@route('/denso/tpms/<filepath:path>')
def static_tpms(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\tpms')

@route('/denso/tpms/files/<filepath:path>')
def static_tpms_files(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\tpms\files')

@route('/denso/tpms/warranty/<filepath:path>')
def static_tpms_warranty(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\tpms\warranty')

@route('/denso/let/data_requests/<filepath:path>')
def static_let_data_requests(filepath):
    return static_file(filepath, root=r'D:\webapps\denso\let\data_requests')

@route('/denso')  # If they are not big brother, show them the feed
def static_denso():
    redirect('/denso/showfeed')


###############################################  Routes for Viewable Directories  ###############################################
@route('/denso/images/index')
def showImages():
    return showListings()

@route('/denso/vids/index')
def showVids():
    return showListings()

@route('/denso/files/index')
def showFiles():
    return showListings()

@route('/denso/audio/index')
def showAudio():
    return showListings()

@route('/denso/tpms/warranty/index')
def showTpmsWarranty():
    return showListings()

####################################################  Dynamic Routings  #####################################################
@route('/denso/request.urlparts')
def requestURL():
    return "scheme: " + request.urlparts[0] + "<br>" + \
           "host: " + request.urlparts[1] + "<br>" + \
           "path: " + request.urlparts[2] + "<br>" + \
           "query_string: " + request.urlparts[3]

@route('/denso/rss')
def getRSS():
    generateRSS()
    return "RSS feed was generated"

@route('/denso/register', method='POST')
def register():
    assocno = request.POST.get('assocno', '').strip()
    userid  = request.POST.get('userid', '').strip()
    fname   = request.POST.get('fname', '').strip()
    lname   = request.POST.get('lname', '').strip()
    workext = request.POST.get('workext', '').strip()
    beeper  = request.POST.get('beeper', '').strip()
    aboutme = request.POST.get('aboutme', '').strip()
    email   = request.POST.get('email', '').strip()
    email_notify = request.POST.get('email_notify', '').strip()
    password = base64.b64encode( request.POST.get('password', '').strip() )

    if hasRegistered(userid):
        output = template(r'D:\webapps\denso\templates\alreadyRegistered.tpl')
        return output
    else:
        datetime_stamp = datetime.now()
        registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, "images/default.bmp", email, email_notify, datetime_stamp)
        response.set_cookie('user', userid)
        output = template(r'D:\webapps\denso\templates\registrationSuccess.tpl', firstname=fname, lastname=lname)
        return output + '<meta http-equiv="REFRESH" content="3;url=/denso/showfeed">'

@route('/denso/login', method='POST')
def login():
    userid = request.POST.get('user', '').strip()
    pw     = base64.b64encode( request.POST.get('password', '').strip() )
    if validUser(userid, pw):
        response.set_cookie('user', userid)
        redirect('/denso/showfeed')
    else:
        output = template(r'D:\webapps\denso\templates\invalid_user.tpl')
        return output

@route('/denso/postmessage', method='POST')
def postMessage():
    userid  = request.get_cookie('user')
    comment = request.POST.get('comment', '').strip()
    target  = request.POST.get('target', '').strip()
    hlink   = request.POST.get('hlink', '').strip()
    datetime_stamp = datetime.now()
    # Get the comment that the user entered in the HTML text box, then format it for HTML
    comment = comment.replace('<','&#60;').replace('>','&#62;')

    hypcomment = hyperlinker(comment, target, hlink)

    if userid:
        insertPost(userid, hypcomment, datetime_stamp)
        generateRSS()
        try:
            sendEmail()
        except:
            print "ERROR: failed to send email(s)"
            redirect('/denso/showfeed')
        redirect('/denso/showfeed')
    else:
        return "You have to be logged in before you can post your message."

@route('/denso/showfeed')
def showFeed():
    userid = request.get_cookie('user')
    if userid:
        resultset = getFeedResultSet()
        output = template(r'D:\webapps\denso\templates\feed_logged_in.tpl', rows=resultset, userprofile=userid)
        return output
    else:
        resultset = getFeedResultSet()
        output = template(r'D:\webapps\denso\templates\feed_logged_out.tpl', rows=resultset)
        return output

@route('/denso/viewprofile', method='GET')
def viewProfile():
    userid = request.GET.get('userid')
    resultset = getUserProfile(userid)
    column_name_list = resultset['column_names']
    row_data_list    = resultset['row_data']
    output = template(r'D:\webapps\denso\templates\viewprofile.tpl', user=userid, column_names=column_name_list, row_data=row_data_list)
    return output

@route('/denso/logout')
def logOut():
    userid = request.get_cookie('user')
    response.set_cookie('user', userid, expires=-1)
    output = template(r'D:\webapps\denso\templates\logged_out.tpl')
    return output

@route('/denso/upload', method='POST')
def upload():
    # Get the URL that the FileUpload.html is located at (ex: http://localhost/denso/images/FileUpload.html)
    requestURL = request.environ.get('HTTP_REFERER')
    url_parser = urlparse(requestURL)

    # Get just the URL suffix (ex: /denso/images/FileUpload.html)
    url_suffix = url_parser.path
    
    # Now map the URL suffix to the server webapp directory
    request_path = "d:\\webapps"+url_suffix.replace("/","\\")  # Since server is on Windoze, need to convert to backslash

    # But we don't need the "FileUpload.html" in the path, so exclude it from the path by finding the right-most backslash
    index = request_path.rfind("\\")
    root_path = request_path[:index+1]

    # Get the file item from the FileUpload.html form
    fileitem = request.POST.get('upfile', '')

    # upload the file to the server at the designated path
    return upload(fileitem, root_path)

@route('/denso/changepw', method='POST')
def changePW():
    userid    = request.get_cookie('user')
    currentPW = base64.b64encode( request.POST.get('password', '').strip() )
    newPW     = base64.b64encode( request.POST.get('password1', '').strip() )
    if validUser(userid, currentPW):
        changePWD(userid, newPW)
        output = template(r'D:\webapps\denso\templates\password_changed.tpl')
        return output
    else:
        output = template(r'D:\webapps\denso\templates\incorrect_password.tpl')
        return output

@route('/denso/getpwd', method='POST')
def getPWD():
    userid = request.POST.get('userid', '').strip()
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = "select password from users where userid=?"
    c.execute(sql, [userid])
    conn.commit()
    resultset = c.fetchone()
    c.close()
    conn.close()
    return "Fuzzied password is: ", resultset[0]

##################################################  Application Specific Routes  ##################################################
@route('/denso/tpms', method='POST')
def tpms():
    querystr = request.POST.get('qryParameter', '').strip().upper()
    cnxn_string = "DRIVER={MySQL ODBC 5.1 Driver};SERVER=XPO38498;PORT=3306;DATABASE=test;UID=read;PWD=;OPTION=3"

    cnxn = pyodbc.connect(cnxn_string)
    cursor = cnxn.cursor()

    # Get the resultset
    resultset = TpmsLookUp.getResultset(querystr, cursor)
    cnxn.commit()

    # Get column name of the resultset
    column_name_list = [tuple[0] for tuple in cursor.description]
    
    cursor.close()
    cnxn.close()

    output = template(r'D:\webapps\_templates\make_table.tpl', rows=resultset, column_names=column_name_list)
    return output

@route('/denso/VinSearch', method='POST')
def VinSearch():
    querystr = request.POST.get('qryParameter', '').strip().upper()

    # Get password and "de-fuzzy" it
    pw_file = open(r'D:\webapps\_server\pyodbc\cmq.txt', 'r')
    pw = base64.b64decode(pw_file.read())
    userid = 'rb10'
    pw_file.close()

    cnxn_string = 'DSN=CMQ_PROD;UID=' + userid + ';PWD=' + pw
    
    cnxn = pyodbc.connect(cnxn_string)

    ###################################  Get VIN production and features info  #############################
    cursor = cnxn.cursor()
    # Get the resultset
    vinProdFeatures = VinLookUp.getVinProdFeatures(querystr, cursor)
    cnxn.commit()

    # Get column names of the resultset
    vinProdFeaturesHeader = [tuple[0] for tuple in cursor.description]
    
    cursor.close()

    #####################  Get VIN warranty info  #####################
    cursor = cnxn.cursor()
    # Get the resultset
    vinWarranty = VinLookUp.getVinWarranty(querystr, cursor)
    cnxn.commit()

    # Get column names of the resultset
    vinWarrantyHeader = [tuple[0] for tuple in cursor.description]

    cursor.close()

    #####################  Get VIN HDS info  ########################
    cursor = cnxn.cursor()
    # Get the resultset
    vinHds = VinLookUp.getVinHDS(querystr, cursor)
    cnxn.commit()

    # Get column names of the resultset
    vinHdsHeader = [tuple[0] for tuple in cursor.description]

    cursor.close()

    #####################  Get Claim DTCs  #######################
    cursor = cnxn.cursor()
    # Get the resultset
    vinDtc = VinLookUp.getClaimDTC(querystr, cursor)
    cnxn.commit()

    # Get column names of the resultset
    vinDtcHeader = [tuple[0] for tuple in cursor.description]

    cursor.close()

    ###############################################################################
    cnxn.close()  #  When done making resultsets, close the connection
    ###############################################################################

    output = template(r'D:\webapps\_templates\Vin.tpl', rowsVinProd=vinProdFeatures, columnsVinProdFeatures=vinProdFeaturesHeader,
                rowsVinWarranty=vinWarranty, columnsVinWarranty=vinWarrantyHeader,
                rowsVinHds=vinHds, columnsVinHds=vinHdsHeader,
                rowsVinDtc=vinDtc, columnsVinDtc=vinDtcHeader
             )
    return output

@route('/denso/lot2date', method='POST')
def lot2date():
    lotcode = request.POST.get('qryParameter', '').strip().upper()
    supplier = request.POST.get('supplier', '').strip()

    if supplier=="TRW":
        sensor_date = tpms_lot2date.trw_lot2date(lotcode)
        supplier = "TRW"
    elif supplier=="Pacific":
        sensor_date = tpms_lot2date.pacific_lot2date(lotcode)
        supplier = "Pacific"
    else:
        sensor_date = tpms_lot2date.continental_lot2date(lotcode)
        supplier = "Continental"

    output = supplier,"'s", " lot code: ", lotcode, " = ", str(sensor_date)
    return output

@route('/denso/wpi2wpt', method='POST')
def wpi2wpt():
    part5      = request.POST.get('part5', '').strip()
    start_date = request.POST.get('start_date', '').strip()
    
    # Get password and "de-fuzzy" it
    pw_file = open(r'D:\webapps\_server\pyodbc\cmq.txt', 'r')
    pw = base64.b64decode(pw_file.read())
    userid = 'rb10'
    pw_file.close()

    cnxn_string = 'DSN=CMQ_PROD;UID=' + userid + ';PWD=' + pw
    
    cnxn = pyodbc.connect(cnxn_string)

    # Get connection cursor
    cursor = cnxn.cursor()

    # Get the resultset
    wpi2wpt_rows = WpiLeftJoinWpt.getWpiLeftJoinWpt(part5, start_date, cursor)
    cnxn.commit()

    # Get column names of the resultset
    wpi2wpt_header = [tuple[0] for tuple in cursor.description]
    
    cursor.close()
    cnxn.close()

    # Send response as an Excel file
    response.content_type = 'application/vnd.ms-excel'
    output = template(r'D:\webapps\_templates\make_table.tpl', rows=wpi2wpt_rows, column_names=wpi2wpt_header)
    return output

@route('/denso/PwgNoAnalysis')
def getPwgNoAnalysis():
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    cursor = conn.cursor()
    sql = "select * from PWG_Parts_Tracking where date_analysis_recd is Null order by date_sent"
    
    cursor.execute(sql)
    conn.commit()

    resultset = cursor.fetchall()
    resultset_header = [tuple[0] for tuple in cursor.description]

    cursor.close()
    conn.close()

    # response.content_type = 'application/vnd.ms-excel'
    output = template(r'D:\webapps\_templates\make_table.tpl', rows=resultset, column_names=resultset_header)
    return output

###################################################  Below are helper functions  ##################################################

def registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
insert into users values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    c.execute(sql, [assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def hasRegistered(userid):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
select
userid

from users

where
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def validUser(userid, pw):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
select
userid,
password

from users

where
userid = ?
and password = ?"""

    c.execute(sql, [userid,pw])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def hyperlinker (full_text, target, hyperlink):
    if target == '' or hyperlink == '':
        return full_text
    else:
        if full_text.find(target) == -1:
            print '<h2>Your target word was not found.  Hit the back button.</h2>'
            sys.exit()
        else:
            anchor = '<a href="' + hyperlink + '">' + target + "</a>"
            return full_text.replace(target, anchor)

def insertPost(userid, txt, datetime_stamp):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
    insert into feed (userid, feedtxt, datetime_stamp)
    values (?, ?, ?)"""

    c.execute(sql, [userid, txt, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def sendEmail():
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = "select email from users where email_notify = 'True'"

    c.execute(sql)
    conn.commit()

    recipient = []
    for row in c:
        recipient.append(row[0])

    c.close()
    conn.close()

    pw_file = open(r'D:\webapps\_server\email\pw.txt', 'r')
    pwd = base64.b64decode( pw_file.read() )
    sender  = 'pyfeeds@gmail.com'
    subject = 'HNAS MQ Denso Feed Notification'
    message = "A post has been made to the HNAS Quality Denso feed:  http://10.60.26.120/denso  Do NOT reply."

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['BCC'] = COMMASPACE.join(recipient)
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()

    try:
        server.login(sender,pwd)
    except smtplib.SMTPAuthenticationError:               # Check for authentication error
        return "ERROR"

    try:
        server.sendmail(sender,recipient,msg.as_string())
    except smtplib.SMTPRecipientsRefused:                # Check if recipient's email was accepted by the server
        return "ERROR"
    server.quit()

def getFeedResultSet():
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
assocnum,
substr(fname,1,1),
lname,
img_url

from feed f inner join users u on
f.userid = u.userid

order by
f.datetime_stamp desc
"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchmany(50)
    c.close()
    conn.close()

    return resultset

def getUserProfile(userid):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
select
assocnum as "Assoc #",
userid as "User ID",
fname as "First Name",
lname as "Last Name",
workext as "WorkExt",
beeper as "Beeper",
aboutme as "AboutMe",
img_url as "Img URL",
email as "Email",
email_notify as "Email Notify"

from users

where 
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()
    row_data_list = c.fetchone()
    column_name_list = [tuple[0] for tuple in c.description]
    c.close()
    conn.close()
    resultset = {'column_names':column_name_list, 'row_data':row_data_list}
    return resultset


# Generator to buffer file chunks during file upload
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk

def upload(filenm, path):
    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = filenm
    root_path = path

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'

# Generate RSS Feed
def generateRSS():
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
fname,
lname

from feed f inner join users u on
f.userid = u.userid

order by
f.datetime_stamp desc
"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchmany(15)
    c.close()
    conn.close()

    xml_start = """<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
<channel>
<title>Denso Dept Feed</title>
<link>http://10.44.16.76/denso</link>
<description>Denso Dept Activity</description>
<language>en-us</language>
<lastBuildDate>"""

    xml_item = ""
    for row in resultset:
        author     = row[0]
        description    = row[1]
        datesource = row[2]
        fname      = row[3]
        lname      = row[4]

        year  = int(datesource[:4])
        month = int(datesource[5:7])
        day   = int(datesource[8:10])
        hour  = int(datesource[11:13])
        mins  = int(datesource[14:16])
        sec   = int(datesource[17:19])

        mydate = datetime(year, month, day, hour, mins, sec)

        # Sample format that the publish date needs to be in: Mon, 7 May 2012 16:23:41 GMT
        pubDate = mydate.strftime("%a, %d %b %Y %H:%M:%S UT")
        postDate = mydate.strftime("%a %m/%d/%y %I:%M%p")

        xml_item = xml_item + "<item>\n" + \
 "  <title>" + postDate + " " + "(" + fname[:1] + "." + lname + ")" + "</title>\n" + \
 "  <description>\n" + description + "\n" + "  </description>\n" +  \
 "  <pubDate>" + pubDate + "</pubDate>\n" + \
 "  <link>http://10.44.16.76/denso</link>\n</item>\n"


    xml_end = """<!-- END RSS Items -->
</channel>
</rss>"""

    now = datetime.now()
    xml_rss = xml_start + now.strftime("%a, %d %b %Y %H:%M:%S UT") + "</lastBuildDate>\n" + xml_item + xml_end

    rss_file = open(r'D:\webapps\denso\rss\denso.rss','w')
    rss_file.write(xml_rss)
    rss_file.close()

def changePWD(userid, pw):
    conn = sqlite3.connect(r'D:\webapps\denso\server\db\denso')
    c = conn.cursor()

    sql = "update users set password=? where userid=?"

    c.execute(sql, [pw, userid])
    conn.commit()
    c.close()
    conn.close()

def showListings():
    """This function allows a directory's contents to be listed"""

    url_suffix = request.urlparts[2] # /www/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /www/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

def showListingsWithOutFileUpload():
    """This function allows a directory's contents to be listed except for FileUpload.html file"""

    url_suffix = request.urlparts[2] # /www/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /www/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            if filename != '_FileUpload.html':
                filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output
