from bottle import route, static_file, request, response, redirect, template
from datetime import datetime
from email.mime.text import MIMEText
from email.utils import COMMASPACE
from urlparse import urlparse
import os, sqlite3, base64, smtplib

####################################################  Static Routings  #######################################################
@route('/engine/<filename>')
def server_static(filename):
    return static_file(filename, root=r'D:\webapps\engine')

@route('/engine/source/<filename>')
def static_source(filename):
    return static_file(filename, root=r'D:\webapps\engine\source')

@route('/engine/images/<filepath:path>') 
def static_images(filepath):
    return static_file(filepath, root=r'D:\webapps\engine\images')

@route('/engine/vids/<filepath:path>')
def static_vids(filepath):
    return static_file(filepath, root=r'D:\webapps\engine\vids')

@route('/engine/files/<filepath:path>')
def static_files(filepath):
    return static_file(filepath, root=r'D:\webapps\engine\files')

@route('/engine/rss/<filepath:path>')
def static_rss(filepath):
    return static_file(filepath, root=r'D:\webapps\engine\rss')

@route('/engine') # If they are not big brother, show them the feed
def static_engine():
    requestIP = request.get('REMOTE_ADDR')
    print "Request IP: " + requestIP
    if requestIP[:7] == '207.131':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/HAM/default.aspx')
    elif requestIP[:6] == 'hdcinf':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/HAM/default.aspx')
    else:
        redirect('/engine/showfeed')

###############################################  Routes for Viewable Directories  ###############################################
@route('/engine/images/index')
def showImages():
    url_suffix = request.urlparts[2] # /engine/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /engine/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/engine/vids/index')
def showVids():
    url_suffix = request.urlparts[2] # /engine/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /engine/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/engine/files/index')
def showFiles():
    url_suffix = request.urlparts[2] # /engine/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /engine/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/engine/audio/index')
def showAudio():
    url_suffix = request.urlparts[2] # /engine/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /engine/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\www\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output


####################################################  Dynamic Routings  #####################################################
@route('/engine/request.urlparts')
def requestURL():
    return "scheme: " + request.urlparts[0] + "<br>" + \
           "host: " + request.urlparts[1] + "<br>" + \
           "path: " + request.urlparts[2] + "<br>" + \
           "query_string: " + request.urlparts[3]

@route('/engine/rss')
def getRSS():
    generateRSS()
    return "RSS feed was generated"

@route('/engine/register', method='POST')
def register():
    assocno = request.POST.get('assocno', '').strip()
    userid  = request.POST.get('userid', '').strip()
    fname   = request.POST.get('fname', '').strip()
    lname   = request.POST.get('lname', '').strip()
    workext = request.POST.get('workext', '').strip()
    beeper  = request.POST.get('beeper', '').strip()
    aboutme = request.POST.get('aboutme', '').strip()
    email   = request.POST.get('email', '').strip()
    email_notify = request.POST.get('email_notify', '').strip()
    password = base64.b64encode( request.POST.get('password', '').strip() )

    if hasRegistered(userid):
        output = template(r'D:\webapps\engine\templates\alreadyRegistered.tpl')
        return output
    else:
        datetime_stamp = datetime.now()
        registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, "images/default.bmp", email, email_notify, datetime_stamp)
        response.set_cookie('user', userid)
        output = template(r'D:\webapps\engine\templates\registrationSuccess.tpl', firstname=fname, lastname=lname)
        return output + '<meta http-equiv="REFRESH" content="3;url=/engine/showfeed">'

@route('/engine/login', method='POST')
def login():
    userid = request.POST.get('user', '').strip()
    pw     = base64.b64encode( request.POST.get('password', '').strip() )
    if validUser(userid, pw):
        response.set_cookie('user', userid)
        redirect('/engine/showfeed')
    else:
        output = template(r'D:\webapps\engine\templates\invalid_user.tpl')
        return output

@route('/engine/postmessage', method='POST')
def postMessage():
    userid  = request.get_cookie('user')
    comment = request.POST.get('comment', '').strip()
    target  = request.POST.get('target', '').strip()
    hlink   = request.POST.get('hlink', '').strip()
    datetime_stamp = datetime.now()
    # Get the comment that the user entered in the HTML text box, then format it for HTML
    comment = comment.replace('<','&#60;').replace('>','&#62;')

    hypcomment = hyperlinker(comment, target, hlink)

    if userid:
        insertPost(userid, hypcomment, datetime_stamp)
        generateRSS()
        try:
            sendEmail()
        except:
            print "ERROR: failed to send email(s)"
            redirect('/engine/showfeed')
        redirect('/engine/showfeed')
    else:
        return "You have to be logged in before you can post your message."

@route('/engine/showfeed')
def showFeed():
    requestIP = request.get('REMOTE_ADDR')
    print "Request IP: " + requestIP
    if requestIP[:7] == '207.131':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/HAM/default.aspx')
    elif requestIP[:6] == 'hdcinf':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/HAM/default.aspx')
    else:
        userid = request.get_cookie('user')   
        if userid:
            resultset = getFeedResultSet()
            output = template(r'D:\webapps\engine\templates\feed_logged_in.tpl', rows=resultset, userprofile=userid)
            return output
        else:
            resultset = getFeedResultSet()
            output = template(r'D:\webapps\engine\templates\feed_logged_out.tpl', rows=resultset)
            return output

@route('/engine/viewprofile', method='GET')
def viewProfile():
    userid = request.GET.get('userid')
    resultset = getUserProfile(userid)
    column_name_list = resultset['column_names']
    row_data_list    = resultset['row_data']
    output = template(r'D:\webapps\engine\templates\viewprofile.tpl', user=userid, column_names=column_name_list, row_data=row_data_list)
    return output

@route('/engine/logout')
def logOut():
    userid = request.get_cookie('user')
    response.set_cookie('user', userid, expires=-1)
    output = template(r'D:\webapps\engine\templates\logged_out.tpl')
    return output

@route('/engine/upload', method='POST')
def upload():
    # Get the URL that the FileUpload.html is located at (ex: http://localhost/engine/images/FileUpload.html)
    requestURL = request.environ.get('HTTP_REFERER')
    url_parser = urlparse(requestURL)

    # Get just the URL suffix (ex: /engine/images/FileUpload.html)
    url_suffix = url_parser.path
    
    # Now map the URL suffix to the server webapp directory
    request_path = "d:\\webapps"+url_suffix.replace("/","\\")  # Since server is on Windoze, need to convert to backslash

    # But we don't need the "FileUpload.html" in the path, so exclude it from the path by finding the right-most backslash
    index = request_path.rfind("\\")
    root_path = request_path[:index+1]

    # Get the file item from the FileUpload.html form
    fileitem = request.POST.get('upfile', '')

    # upload the file to the server at the designated path
    return upload(fileitem, root_path)

@route('/engine/changepw', method='POST')
def changePW():
    userid    = request.get_cookie('user')
    currentPW = base64.b64encode( request.POST.get('password', '').strip() )
    newPW     = base64.b64encode( request.POST.get('password1', '').strip() )
    if validUser(userid, currentPW):
        changePWD(userid, newPW)
        output = template(r'D:\webapps\engine\templates\password_changed.tpl')
        return output
    else:
        output = template(r'D:\webapps\engine\templates\incorrect_password.tpl')
        return output
    

###################################################  Below are helper functions  ##################################################

def registerUser(assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
insert into users values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    c.execute(sql, [assocno, userid, fname, lname, workext, beeper, aboutme, password, img_url, email, email_notify, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def hasRegistered(userid):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
select
userid

from users

where
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def validUser(userid, pw):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
select
userid,
password

from users

where
userid = ?
and password = ?"""

    c.execute(sql, [userid,pw])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def hyperlinker (full_text, target, hyperlink):
    if target == '' or hyperlink == '':
        return full_text
    else:
        if full_text.find(target) == -1:
            print '<h2>Your target word was not found.  Hit the back button.</h2>'
            sys.exit()
        else:
            anchor = '<a href="' + hyperlink + '">' + target + "</a>"
            return full_text.replace(target, anchor)

def insertPost(userid, txt, datetime_stamp):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
    insert into feed (userid, feedtxt, datetime_stamp)
    values (?, ?, ?)"""

    c.execute(sql, [userid, txt, datetime_stamp])
    conn.commit()
    c.close()
    conn.close()

def sendEmail():
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = "select email from users where email_notify = 'True'"

    c.execute(sql)
    conn.commit()

    recipient = []
    for row in c:
        recipient.append(row[0])

    c.close()
    conn.close()

    pw_file = open(r'D:\webapps\_server\email\pw.txt', 'r')
    pwd = base64.b64decode( pw_file.read() )
    sender  = 'pyfeeds@gmail.com'
    subject = 'Feed Notification'
    message = "A post has been made to the Engine Dept Feed:  http://10.44.16.86/engine  Do NOT reply."

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['BCC'] = COMMASPACE.join(recipient)
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()

    try:
        server.login(sender,pwd)
    except smtplib.SMTPAuthenticationError:               # Check for authentication error
        return "ERROR"

    try:
        server.sendmail(sender,recipient,msg.as_string())
    except smtplib.SMTPRecipientsRefused:                # Check if recipient's email was accepted by the server
        return "ERROR"
    server.quit()

def getFeedResultSet():
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
assocnum,
substr(fname,1,1),
lname,
img_url

from feed f inner join users u on
f.userid = u.userid

order by
f.datetime_stamp desc
"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchmany(50)
    c.close()
    conn.close()

    return resultset

def getUserProfile(userid):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
select
assocnum as "Assoc #",
userid as "User ID",
fname as "First Name",
lname as "Last Name",
workext as "WorkExt",
beeper as "Beeper",
aboutme as "AboutMe",
img_url as "Img URL",
email as "Email",
email_notify as "Email Notify"

from users

where 
userid = ?"""

    c.execute(sql, [userid])
    conn.commit()
    row_data_list = c.fetchone()
    column_name_list = [tuple[0] for tuple in c.description]
    c.close()
    conn.close()
    resultset = {'column_names':column_name_list, 'row_data':row_data_list}
    return resultset


# Generator to buffer file chunks during file upload
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk

# Main file upload function
def upload(filenm, path):
    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = filenm
    root_path = path

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'

# Generate RSS Feed
def generateRSS():
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = """
select
u.userid,
feedtxt,
f.datetime_stamp,
fname,
lname

from feed f inner join users u on
f.userid = u.userid

order by
f.datetime_stamp desc
"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchmany(15)
    c.close()
    conn.close()

    xml_start = """<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0">
<channel>
<title>Engine Dept Feed</title>
<link>http://10.44.16.86/engine</link>
<description>Engine Dept Activity</description>
<language>en-us</language>
<lastBuildDate>"""

    xml_item = ""
    for row in resultset:
        author     = row[0]
        description    = row[1]
        datesource = row[2]
        fname      = row[3]
        lname      = row[4]

        year  = int(datesource[:4])
        month = int(datesource[5:7])
        day   = int(datesource[8:10])
        hour  = int(datesource[11:13])
        mins  = int(datesource[14:16])
        sec   = int(datesource[17:19])

        mydate = datetime(year, month, day, hour, mins, sec)

        # Sample format that the publish date needs to be in: Mon, 7 May 2012 16:23:41 GMT
        pubDate = mydate.strftime("%a, %d %b %Y %H:%M:%S UT")
        postDate = mydate.strftime("%a %m/%d/%y %I:%M%p")

        xml_item = xml_item + "<item>\n" + \
 "  <title>" + postDate + " " + "(" + fname[:1] + "." + lname + ")" + "</title>\n" + \
 "  <description>\n" + description + "\n" + "  </description>\n" +  \
 "  <pubDate>" + pubDate + "</pubDate>\n" + \
 "  <link>http://10.44.16.86/engine</link>\n</item>\n"


    xml_end = """<!-- END RSS Items -->
</channel>
</rss>"""

    now = datetime.now()
    xml_rss = xml_start + now.strftime("%a, %d %b %Y %H:%M:%S UT") + "</lastBuildDate>\n" + xml_item + xml_end

    rss_file = open(r'D:\webapps\engine\rss\engine.rss','w')
    rss_file.write(xml_rss)
    rss_file.close()

def changePWD(userid, pw):
    conn = sqlite3.connect(r'D:\webapps\engine\server\db\engine')
    c = conn.cursor()

    sql = "update users set password=? where userid=?"

    c.execute(sql, [pw, userid])
    conn.commit()
    c.close()
    conn.close()
