from bottle import route, static_file, redirect, request, response, template
from urlparse import urlparse
import os


###########################################  Static Routings for captions webapp  ###########################################
@route('/captions/<filename>')
def server_static(filename):
    return static_file(filename, root=r'D:\webapps\captions')

@route('/captions/source/<filename>')
def static_source(filename):
    response.set_header('Content-Type','text/plain')
    return static_file(filename, root=r'D:\webapps\captions\source')

@route('/captions/images/<filepath:path>')
def static_images(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\images')

@route('/captions/vids/<filepath:path>')
def static_vids(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\vids')

@route('/captions/audio/<filepath:path>')
def static_audio(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\audio')

@route('/captions/files/<filepath:path>')
def static_files(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\files')

@route('/captions/source-files/<filepath:path>')
def static_sourcefiles(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\source-files')

@route('/captions/www/<filepath:path>')
def static_www(filepath):
    return static_file(filepath, root=r'D:\webapps\captions\www')

@route('/captions')
def static_captions():
    redirect('/captions/index.html')


###############################################  Routes for Viewable Directories  ###############################################
@route('/captions/images/index')
def showImages():
    url_suffix = request.urlparts[2] # /captions/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /captions/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\captions\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/captions/vids/index')
def showVids():
    url_suffix = request.urlparts[2] # /captions/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /captions/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\captions\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/captions/files/index')
def showFiles():
    url_suffix = request.urlparts[2] # /captions/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /captions/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\captions\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/captions/audio/index')
def showAudio():
    url_suffix = request.urlparts[2] # /captions/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /captions/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\captions\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output


#############################################  Dynamic Routings for captions webapp  ##########################################

@route('/captions/addcaption', method='POST')
def addCaption():
    # get the caption comment
    comment = request.POST.get('comment', '').strip()
    
    # Go get the URL/html page that the user requested
    http_referer = request.environ.get('HTTP_REFERER') # For example:  http://localhost/captions/index.html

    # Now just get the URL suffix, we don't care about the full URL
    url_parser = urlparse(http_referer)
    url_suffix = url_parser.path
    # url_suffix = '/captions/index.html'

    orig_file = "d:\\webapps"+url_suffix.replace("/","\\")
    # original file = "d:\webapps\captions\index.html"

    # Now prepare temporary file which we will later replace the original file with, we are going to keep the same name, but add _bak at the end
    temp_file = orig_file.replace(".html","_bak.html")
    # temp file = "d:\webapps\captions\index_bak.html"

    # Now create input file for read-only access and output file for write access
    input_file = open(orig_file,'r')
    output_file = open(temp_file,'w')

    # Format comment for HTML
    comment = comment.replace('<','&#60;').replace('>','&#62;')
    comment_formatted = "<p>\"" + comment + "\"</p>\n"

    # Read the entire contents of the orginal file as lines stored in a list (a list of lines)
    lines_list = input_file.readlines()  #  FYI, this is very inefficient. Do not use readlines() if there are several thousands of comments...

    input_file.close()

    # Find where the first comment is in the HTML page
    index = lines_list.index("<!-- START COMMENTS -->\n")

    # Now insert the new comment at the top of the comments
    lines_list.insert(index+1,comment_formatted)

    # Now write the contents of the new HTML file to the temporary output file
    for line in lines_list:
        output_file.write(line)

    output_file.close()

    # Now swap the original file with the temporary file with updated user comments
    in_file = open(temp_file,'r')
    out_file = open(orig_file,'w')

    in_file_contents = in_file.read()
    out_file.write(in_file_contents)

    in_file.close()
    out_file.close()

    redirect(http_referer)

@route('/captions/upload', method='POST')
def upload():
    # Get the URL that the FileUpload.html is located at (ex: http://localhost/denso/images/FileUpload.html)
    requestURL = request.environ.get('HTTP_REFERER')
    url_parser = urlparse(requestURL)

    # Get just the URL suffix (ex: /denso/images/FileUpload.html)
    url_suffix = url_parser.path
    
    # Now map the URL suffix to the server webapp directory
    request_path = "d:\\webapps"+url_suffix.replace("/","\\")  # Since server is on Windoze, need to convert to backslash

    # But we don't need the "FileUpload.html" in the path, so exclude it from the path by finding the right-most backslash
    index = request_path.rfind("\\")
    root_path = request_path[:index+1]

    # Get the file item from the FileUpload.html form
    fileitem = request.POST.get('upfile', '')

    # upload the file to the server at the designated path
    return upload(fileitem, root_path)

    
###############################  Helper Functions  ############################
# Generator to buffer file chunks during file upload
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk

# Main file upload function
def upload(filenm, path):

    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = filenm
    root_path = path

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'
