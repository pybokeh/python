insert or replace into fcm_angles_no_dupes (txtVIN, Pitch, Roll, Yaw, datTime, txtMY, txtModel, txtPlant, testYrMonth)

select
txtVIN,
pitch,
roll,
yaw,
date(max(datTime)),
txtMY,
txtModel,
txtPlant,
strftime('%Y-%m',date(max(datTime)))

from fcm_camera

group by
txtVIN
