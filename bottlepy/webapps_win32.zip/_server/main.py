# Reference for wsgilog: https://gist.github.com/3654741

import bottle
from bottle import request, response, redirect
from wsgilog import WsgiLog
# import custom webapps
import www, denso, engine, captions, aq, survey, logging, tpms, visualtips

app = bottle.app()


# This hook allows you to execute code before or after all URL requests
@app.hook('before_request')
def before_request():
    request.environ['wsgilog.logger'].info('Before request to %s %s %s %s' % (request.remote_addr, request.method, request.path, response.status_code))
    if request.remote_addr[:7] == '207.131' or request.remote_addr[:7] == '207.130':
        print "BIG BROTHER was REDIRECTED"
        redirect('http://hondateamlink.ham.am.honda.com/ham/SitePages/Home.aspx')


app = WsgiLog(app, tostream=True)

#bottle.debug(True)
#bottle.run(app=app, host='xpo38498', port=80, server='cherrypy')

# Run this if you want to run bottle with built-in reference WSGI server
# bottle.run(host='10.60.26.120', port=80)
bottle.run(app=app, host='10.60.26.120', port=80, server='cherrypy')
# bottle.run(app=app, host='xpo38498', port=80)
