from bottle import route, static_file, request, response, template
from urlparse import urlparse
import os, sqlite3

###########################################  Static Routings for survey webapp  ###########################################
@route('/survey/<filename>')
def server_static(filename):
    return static_file(filename, root=r'D:\webapps\survey')

@route('/survey/source/<filename>')
def static_source(filename):
    response.set_header('Content-Type','text/plain')
    return static_file(filename, root=r'D:\webapps\survey\source')

@route('/survey/images/<filepath:path>')
def static_images(filepath):
    return static_file(filepath, root=r'D:\webapps\survey\images')

@route('/survey/vids/<filepath:path>')
def static_vids(filepath):
    return static_file(filepath, root=r'D:\webapps\survey\vids')

@route('/survey/audio/<filepath:path>')
def static_audio(filepath):
    return static_file(filepath, root=r'D:\webapps\survey\audio')

@route('/survey/files/<filepath:path>')
def static_files(filepath):
    return static_file(filepath, root=r'D:\webapps\survey\files')

@route('/survey/www/<filepath:path>')
def static_www(filepath):
    return static_file(filepath, root=r'D:\webapps\survey\www')

@route('/survey')
def static_index(filepath):
    return redirect('/survey/index.html')


###############################################  Routes for Viewable Directories  ###############################################
@route('/survey/images/index')
def showImages():
    url_suffix = request.urlparts[2] # /survey/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /survey/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\survey\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/survey/vids/index')
def showVids():
    url_suffix = request.urlparts[2] # /survey/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /survey/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\survey\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/survey/files/index')
def showFiles():
    url_suffix = request.urlparts[2] # /survey/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /survey/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\survey\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output

@route('/survey/audio/index')
def showAudio():
    url_suffix = request.urlparts[2] # /survey/images/index

    # But exclude "index" from the url suffix
    index = url_suffix.rfind("/")
    url_path = url_suffix[:index+1] # now we have only /survey/images/

    server_path = "d:\\webapps"+url_path.replace("/","\\")  # replace forward slash with back slash since we're on Windoze
                                                            # now we have d:\webapps\survey\images\
    filelist = []
    for filename in os.listdir(server_path):
        if os.path.isfile(server_path+filename):  # if the path is a file type, then append to the file list
            filelist.append(filename)

    output = template(r'D:\webapps\_templates\create_index.tpl', files=filelist)

    return output


#############################################  Dynamic Routings for survey webapp  ##########################################

@route('/survey/govote', method='POST')
def goVote():
    requestIP = request.get('REMOTE_ADDR')
    answer    = request.POST.get('checkbox', '')
    
    if hasVoted(requestIP):
        output = '<h3>Sorry, you have already voted from this computer.  Click the Back button or click <a HREF="/survey/showresults">here</a> to view results.</h3>'
        return output
    else:
        insertVote(requestIP, answer)
        output = template(r'D:\webapps\survey\templates\vote_successful.tpl', vote=answer)
        return output

@route('/survey/showresults', method='GET')
def showResults():
    conn = sqlite3.connect(r'D:\webapps\survey\server\db\survey')
    c = conn.cursor()

    sql = """
select
survey.vote as Response,
count(*) as [# of Votes],
count(*) * t.factor as [% of Total]

from survey
join (
select
100 * 1.0/count(*) as factor

from survey) as t

group by
survey.vote

order by
[# of Votes] desc"""

    c.execute(sql)
    conn.commit()
    resultset = c.fetchall()

    # Get column name of the resultset
    column_name_list = [tuple[0] for tuple in c.description]

    c.close()
    conn.close()
    output = template(r'D:\webapps\_templates\make_table.tpl', rows=resultset, column_names=column_name_list)
    return output

@route('/survey/upload', method='POST')
def upload():
    # Get the URL that the FileUpload.html is located at (ex: http://localhost/denso/images/FileUpload.html)
    requestURL = request.environ.get('HTTP_REFERER')
    url_parser = urlparse(requestURL)

    # Get just the URL suffix (ex: /denso/images/FileUpload.html)
    url_suffix = url_parser.path
    
    # Now map the URL suffix to the server webapp directory
    request_path = "d:\\webapps"+url_suffix.replace("/","\\")  # Since server is on Windoze, need to convert to backslash

    # But we don't need the "FileUpload.html" in the path, so exclude it from the path by finding the right-most backslash
    index = request_path.rfind("\\")
    root_path = request_path[:index+1]

    # Get the file item from the FileUpload.html form
    fileitem = request.POST.get('upfile', '')

    # upload the file to the server at the designated path
    return upload(fileitem, root_path)

    
#######################################################  Helper Functions  #######################################################

def hasVoted(ip):
    conn = sqlite3.connect(r'D:\webapps\survey\server\db\survey')
    c = conn.cursor()

    sql = "select * from survey where ip=?"

    c.execute(sql, [ip])
    conn.commit()

    if c.fetchone() == None:
        c.close()
        conn.close()
        return False
    else:
        c.close()
        conn.close()
        return True

def insertVote(ip, vote):
    conn = sqlite3.connect(r'D:\webapps\survey\server\db\survey')
    c = conn.cursor()
    
    for values in [(ip, vote),]:
        c.execute("insert into survey values(?,?)", values)
    conn.commit()
    c.close()
    conn.close()

# Generator to buffer file chunks during file upload
def fbuffer(f, chunk_size=10000):
   while True:
      chunk = f.read(chunk_size)
      if not chunk: break
      yield chunk

# Main file upload function
def upload(filenm, path):

    try: # Windows needs stdio set for binary mode.
        import msvcrt
        msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
        msvcrt.setmode (1, os.O_BINARY) # stdout = 1
    except ImportError:
        pass

    fileitem = filenm
    root_path = path

    # Test if the file was uploaded
    if fileitem.filename:

        # strip leading path from file name to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename)
        f = open(root_path + fn, 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        return 'The file "' + fn + '" was uploaded successfully'

    else:
        return 'No file was uploaded'
