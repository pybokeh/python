def getResultset(querystr, cursor):
   if querystr.isdigit():
      cursor.execute("""
      SELECT
      EFFDT,
      EMPLID as AssocNo,
      NAME as Lname_Fname,
      PREFERRED_NAME,
      ORIG_HIRE_DT,
      WORK_PHONE,
      PAGER_NO,
      EMPL_ST_DESCR as EMPL_STATUS,
      COMPANY,
      LOCATION,
      HAM_TEAM_NAME_H as TEAM_NAME,
      TEAM_NUMBER,
      DEPTID,
      DEPTNAME,
      DEPT_ENTRY_DT,
      JOBTITLE,
      JOB_ENTRY_DT as JOB_TITLE_ENTRY_DT,
      OPRID,
      OPRDEFNDESC,
      EMAILID,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN DAYS(CURRENT_DATE) - DAYS(JOB_ENTRY_DT)
      ELSE DAYS(EFFDT) - DAYS(JOB_ENTRY_DT)
      END AS DAYS_IN_TITLE,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN decimal(float(DAYS(CURRENT_DATE) - DAYS(JOB_ENTRY_DT))/365,3,1)
      ELSE decimal(float(DAYS(EFFDT) - DAYS(JOB_ENTRY_DT))/365,3,1)
      END AS YRS_IN_TITLE,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN DAYS(CURRENT_DATE) - DAYS(ORIG_HIRE_DT)
      ELSE DAYS(EFFDT) - DAYS(ORIG_HIRE_DT)
      END AS DAYS_AT_HONDA,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN decimal(float(DAYS(CURRENT_DATE) - DAYS(ORIG_HIRE_DT))/365,3,1)
      ELSE decimal(float(DAYS(EFFDT) - DAYS(ORIG_HIRE_DT))/365,3,1)
      END AS YRS_AT_HONDA

      FROM ARS.ASSOCIATE_INFO_VW

      WHERE
      ASSOC_NO = ? ORDER BY NAME""", querystr)
   else:
      cursor.execute("""
      SELECT
      EFFDT,
      EMPLID as AssocNo,
      NAME as Lname_Fname,
      PREFERRED_NAME,
      ORIG_HIRE_DT,
      WORK_PHONE,
      PAGER_NO,
      EMPL_ST_DESCR as EMPL_STATUS,
      COMPANY,
      LOCATION,
      HAM_TEAM_NAME_H as TEAM_NAME,
      TEAM_NUMBER,
      DEPTID,
      DEPTNAME,
      DEPT_ENTRY_DT,
      JOBTITLE,
      JOB_ENTRY_DT as JOB_TITLE_ENTRY_DT,
      OPRID,
      OPRDEFNDESC,
      EMAILID,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN DAYS(CURRENT_DATE) - DAYS(JOB_ENTRY_DT)
      ELSE DAYS(EFFDT) - DAYS(JOB_ENTRY_DT)
      END AS DAYS_IN_TITLE,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN decimal(float(DAYS(CURRENT_DATE) - DAYS(JOB_ENTRY_DT))/365,3,1)
      ELSE decimal(float(DAYS(EFFDT) - DAYS(JOB_ENTRY_DT))/365,3,1)
      END AS YRS_IN_TITLE,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN DAYS(CURRENT_DATE) - DAYS(ORIG_HIRE_DT)
      ELSE DAYS(EFFDT) - DAYS(ORIG_HIRE_DT)
      END AS DAYS_AT_HONDA,

      CASE
      WHEN EMPL_ST_DESCR LIKE 'Active%' THEN decimal(float(DAYS(CURRENT_DATE) - DAYS(ORIG_HIRE_DT))/365,3,1)
      ELSE decimal(float(DAYS(EFFDT) - DAYS(ORIG_HIRE_DT))/365,3,1)
      END AS YRS_AT_HONDA

      FROM ARS.ASSOCIATE_INFO_VW

      WHERE
      LAST_NAME_SRCH like ? ORDER BY NAME""", "%"+querystr.upper()+"%")

   resultset = cursor.fetchall()
   return resultset
